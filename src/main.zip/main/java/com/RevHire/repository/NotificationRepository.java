package com.RevHire.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import com.RevHire.entity.Notification;

public interface NotificationRepository extends JpaRepository<Notification, Long> {
    List<Notification> findByUserUserId(Long userId);
}
